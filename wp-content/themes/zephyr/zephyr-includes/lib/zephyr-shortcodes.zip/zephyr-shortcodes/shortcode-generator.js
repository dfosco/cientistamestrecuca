(function(){
	tinymce.create('tinymce.plugins.zephyrgenerator', {
		createControl : function(id, controlManager) {
			if (id == 'zephyrgenerator_button') {
				var button = controlManager.createButton('zephyrgenerator_button', {
					title : 'Zephyr Shortcode Generator', // title of the button
					image : '../wp-content/plugins/zephyr-shortcodes/images/button.png',  // path to the button's image
					onclick : function() {
						var width = jQuery(window).width(), H = jQuery(window).height(), W = ( 720 < width ) ? 720 : width;
						W = W - 50;
						H = H - 84;
						tb_show( 'Zephyr Shortcode Generator', '#TB_inline?width=' + W + '&height=' + H + '&inlineId=zephyrgenerator-form' );
						var tbl = jQuery('#zephyr-generator-tabs').parent();
						var tbw = tbl.parent();
						var tbt = tbw.find('#TB_title');
						tbl.addClass('zephyr-tb');
						var tbth = tbt.height();
						var tblh = tbw.height() - tbth;
						tbl.css({ 'height' :  tblh+'px' });
					}
				});
				return button;
			}
			return null;
		}
	});
	tinymce.PluginManager.add('zephyrgenerator', tinymce.plugins.zephyrgenerator);
	jQuery(function($){
		var file_frame;
		jQuery('.upload_image_button').live('click', function( event ){
			event.preventDefault();
			if ( file_frame ) {
				file_frame.remove();
				//
			}
			var target = jQuery( this ).data( 'image_target' );
			file_frame = wp.media.frames.file_frame = wp.media({
				title: jQuery( this ).data( 'uploader_title' ),
				button: { text: jQuery( this ).data( 'uploader_button_text' ), },
				multiple: false
			});
			file_frame.on( 'select', function() {
				attachment = file_frame.state().get('selection').first().toJSON();

				$(target).val(attachment.url);
			});
			file_frame.open();
		});
		function refreshCfs() {
			jQuery.post(ajaxurl, {action:'wpseRCF_grid_action_ajax' }, function(data){
				jQuery('#zephyr-cfs').html(data);
			});
		}
		jQuery('.cfss').live('click', function( event ) {
			event.preventDefault();
			jQuery('.cfss').removeClass('act');
			jQuery(this).addClass('act');
		});
		jQuery('#zephyr-addcf').live('click', function( event ) {
			event.preventDefault();
			var cfemail = jQuery('#zephyr-contact-email').val();
			jQuery.post(ajaxurl, {action:'wpseZCF_grid_action_ajax', cfemail: cfemail }, function(data){
				if ( data == true ) {
					jQuery('#zephyr-contact-email').val('');
					refreshCfs();
				}
			});
		});
		jQuery.post(ajaxurl, {action:'wpse73257_grid_action_ajax'}, function(html){
			var form = jQuery(html);
			form.appendTo('body').hide();
			jQuery( "#zephyr-generator-tabs" ).tabs().addClass( "ui-tabs-vertical ui-helper-clearfix" );
			jQuery( "#zephyr-generator-tabs li" ).removeClass( "ui-corner-top" ).addClass( "ui-corner-left" );
			$('#zephyr-button-color').wpColorPicker();
			$('#zephyr-button-border-color').wpColorPicker();
			$('#zephyr-button-text-color').wpColorPicker();
			$('#zephyr-dropcaps-first-color').wpColorPicker();
			$('#zephyr-dropcaps-bg-color').wpColorPicker();
			$('#zephyr-chapter-color').wpColorPicker();
			$('#zephyr-hb-title-color').wpColorPicker();
			$('#zephyr-hb-subtitle-color').wpColorPicker();
			$('#zephyr-counter-percent-slider').slider({
			    range: "min",
				value: 1,
				step: 1,
				min: 0,
				max: 100,
				slide: function(event, ui) {
					$("#zephyr-counter-percent").val(ui.value);
				}
			});
			form.find('#zephyrgenerator-submit').click(function(){
				var shtype = $('#zephyr-generator-tabs').find('li.ui-tabs-active a').attr('href');
				var shortcode = '';
				if ( shtype == '#gen-1' ) {
					// columns
					var colnum = $(shtype).find('input[name=zephyr-columns]:checked').val();
					var i = 0;
					shortcode += '[zephyr_columns]';
					while ( i < colnum ) {
						i++;
						shortcode += '[zephyr_column col="'+colnum+'"]Insert column content here...[/zephyr_column]';
					}
					shortcode += '[/zephyr_columns]';
				}
				if ( shtype == '#gen-2' ) {
					var text = $(shtype).find('input#zephyr-button-text').val();
					var url = $(shtype).find('input#zephyr-button-url').val();
					var style = $(shtype).find('input[name=zephyr-button-style]:checked').val();
					var bgcolor = $(shtype).find('#zephyr-button-color').val();
					var bordercolor = $(shtype).find('#zephyr-button-border-color').val();
					var textcolor = $(shtype).find('#zephyr-button-text-color').val();
					shortcode += '[zephyr_button';
					shortcode += ' url="'+url+'"';
					shortcode += ' style="'+style+'"';
					shortcode += ' bgcolor="'+bgcolor+'"';
					shortcode += ' border="'+bordercolor+'"';
					shortcode += ' textcolor="'+textcolor+'"';
					shortcode += ']'+text+'[/zephyr_button]';
				}
				if ( shtype == '#gen-3' ) {
					var text = $(shtype).find('#zephyr-quote-text').val();
					var author = $(shtype).find('input#zephyr-quote-author').val();
					shortcode += '[zephyr_quote';
					shortcode += ' author="'+author+'"]';
					shortcode += text;
					shortcode += '[/zephyr_quote]';
				}
				if ( shtype == '#gen-4' ) {
					var bgimg = $(shtype).find('#zephyr-hb-bg').val();
					var title = $(shtype).find('#zephyr-hb-title').val();
					var subtitle = $(shtype).find('#zephyr-hb-subtitle').val();
					var titlecolor = $(shtype).find('#zephyr-hb-title-color').val();
					var subtitlecolor = $(shtype).find('#zephyr-hb-subtitlecolor-color').val();
					var height = $(shtype).find('#zephyr-hb-height').val();
					shortcode += '[zephyr_header_block';
					shortcode += ' bgimg="'+bgimg+'"';
					shortcode += ' title="'+title+'"';
					shortcode += ' titlecolor="'+titlecolor+'"';
					shortcode += ' subtitlecolor="'+subtitlecolor+'"';
					shortcode += ' height="'+height+'"';
					shortcode += ' subtitle="'+subtitle+'"]';
					shortcode += 'Insert content here[/zephyr_header_block]';
				}
				if ( shtype == '#gen-5' ) {
					var style = $(shtype).find('input[name=zephyr-divider]:checked').val();
					shortcode += '[zephyr_divider style="'+style+'"]';
				}
				if ( shtype == '#gen-6' ) {
					var title = $(shtype).find('input#zephyr-counter-title').val();
					var percent = $(shtype).find('input#zephyr-counter-percent').val();
					shortcode += '[zephyr_counter title="'+title+'" percent="'+percent+'"]';
				}
				if ( shtype == '#gen-7' ) {
					var title = $(shtype).find('input#zephyr-update-title').val();
					shortcode += '[zephyr_update_box title="'+title+'"]Insert content here[/zephyr_update_box]';
				}
				if ( shtype == '#gen-8' ) {
					var style = $(shtype).find('input[name=zephyr-author-style]:checked').val();
					var name = $(shtype).find('input#zephyr-author-name').val();
					var funct = $(shtype).find('input#zephyr-author-function').val();
					var authorimg = $(shtype).find('input#zephyr-author-image').val();
					var bgimg = $(shtype).find('input#zephyr-author-bgimage').val();
					shortcode += '[zephyr_author_box';
					shortcode += ' style="'+style+'"';
					shortcode += ' bgimg="'+bgimg+'"';
					shortcode += ' authorimg="'+authorimg+'"';
					shortcode += ' name="'+name+'"';
					shortcode += ' function="'+funct+'"]';
					shortcode += 'Insert author description[/zephyr_author_box]';
				}
				if ( shtype == '#gen-9' ) {
					var style = $(shtype).find('input[name=zephyr-dropcaps-style]:checked').val();
					var firstletter = $(shtype).find('#zephyr-dropcaps-first-color').val();
					var bgcolor = $(shtype).find('#zephyr-dropcaps-bg-color').val();
					if ( bgcolor == $(shtype).find('#zephyr-dropcaps-bg-color').data('default-color') ) {
						bgcolor = '';
					}
					shortcode += '[zephyr_dropcaps';
					shortcode += ' style="'+style+'"';
					shortcode += ' firstcolor="'+firstletter+'"';
					shortcode += ' bgcolor="'+bgcolor+'"]';
					shortcode += 'Insert content here[/zephyr_dropcaps]';
				}
				if ( shtype == '#gen-10' ) {
					var bgimg = $(shtype).find('#zephyr-chapter-image').val();
					var number = $(shtype).find('#zephyr-chapter-number').val();
					var title = $(shtype).find('#zephyr-chapter-title').val();
					var bgcolor = $(shtype).find('#zephyr-chapter-color').val();
					shortcode += '[zephyr_chapter';
					shortcode += ' number="'+number+'"';
					shortcode += ' title="'+title+'"';
					shortcode += ' bgimg="'+bgimg+'"';
					shortcode += ' bgcolor="'+bgcolor+'"]';
					shortcode += 'Insert chapter content here[/zephyr_chapter]';
				}
				if ( shtype == '#gen-11' ) {
					var style = $(shtype).find('input[name=zephyr-cinfo-style]:checked').val();
					var bgimg = $(shtype).find('#zephyr-cinfo-bgimg').val();
					var logo = $(shtype).find('#zephyr-cinfo-logo').val();
					var title = $(shtype).find('#zephyr-cinfo-title').val();
					var url = $(shtype).find('#zephyr-cinfo-url').val();
					var founded = $(shtype).find('#zephyr-cinfo-founded').val();
					var location = $(shtype).find('#zephyr-cinfo-location').val();
					shortcode += '[zephyr_company_info';
					shortcode += ' style="'+style+'"';
					shortcode += ' bgimg="'+bgimg+'"';
					shortcode += ' logo="'+logo+'"';
					shortcode += ' title="'+title+'"';
					shortcode += ' url="'+url+'"';
					shortcode += ' founded="'+founded+'"';
					shortcode += ' location="'+location+'"]';
					shortcode += 'Insert company description here[/zephyr_company_info]';
				}
				if ( shtype == '#gen-12' ) {
					var sel = $(shtype).find('.cfss.act');
					if ( sel.length > 0 ) {
						var id = sel.data('cfid');
					} else {
						var id = '';
					}
					shortcode += '[zephyr_contact_form';
					shortcode += ' id="'+id+'"';
					shortcode += ']';
				}
				if ( shtype == '#gen-13' ) {
					var lat = $(shtype).find('#zephyr-gmaps-latitude').val();
					var long = $(shtype).find('#zephyr-gmaps-longitude').val();
					var zoom = $(shtype).find('#zephyr-gmaps-zoom').val();
					var marker = $(shtype).find('#zephyr-gmaps-marker').val();
					var height = $(shtype).find('#zephyr-gmaps-height').val();
					shortcode += '[zephyr_gmap';
					shortcode += ' latitude="'+lat+'"';
					shortcode += ' longitude="'+long+'"';
					shortcode += ' zoom="'+zoom+'"';
					shortcode += ' message="'+marker+'"';
					shortcode += ' height="'+height+'"';
					shortcode += ']';
				}
				if ( shtype == '#gen-14' ) {
					shortcode += '[zephyr_spacer]';;
				}
				tinyMCE.activeEditor.execCommand('mceInsertContent', 0, shortcode);
				tb_remove();
			});
		});
	});
})()