	function validateValue(ci) { 
		var v = ci.val();
		// console.log(ci);
		if ( ci.attr('type') === 'email' ) {
			if ( validateEmail(v) ) {
				ci.parent().parent().find('.okay').addClass('active');
				ci.parent().parent().find('.error').removeClass('active');
				ci.removeClass('invalid');
				return true;						
			} else {
				ci.parent().parent().find('.okay').removeClass('active');
				ci.parent().parent().find('.error').addClass('active');	
				ci.addClass('invalid');
				return false;
			}
		} else {
			if ( v.length > 1 ) {
				ci.parent().parent().find('.okay').addClass('active');
				ci.parent().parent().find('.error').removeClass('active');
				ci.removeClass('invalid');
				return true;
			} else {
				ci.parent().parent().find('.okay').removeClass('active');
				ci.parent().parent().find('.error').addClass('active');	
				ci.addClass('invalid');
				return false;
			}
		}
	}	
	function validateEmail(email) { 
		var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(email);
	}
jQuery( function($) {
	$('.form-row input').each( function() {
		var ci = $(this);
		ci.parent().parent().append('<div class="zephyr-validation"><div class="error"></div><div class="okay"></div></div>');
		ci.keypress( function() { x = true; validateValue(ci); } );
	});
	$('#sendform').click( function() {
		$('.loading').css({'opacity':'1'});
		var form = $(this).parent().parent();
		var name = form.find('#yourname');
		var email = form.find('#youremail');
		var message = form.find('#yourmess').val();
		var id = form.find('#zcf-id').val();
		if ( validateValue(name) && validateValue(email) ) {
			jQuery.post( ZephyrAjax.ajaxurl, {
				action : 'myajax-submit',
				name : name.val(),
				email : email.val(),
				message : message,
				id : id
			}, function( response ) {
			//	var resp = jQuery.parseJSON(response);
				if ( response.success == 'true' ) {
					$('.loading').css({'opacity':'0'});
					$('#sendform').fadeOut(300);
				}
			}, 'json');
		} else {
			$('.loading').css({'opacity':'0'});
		}
	});
	$('.form-row').click( function() {
		$(this).find(':input').focus();
	});
});