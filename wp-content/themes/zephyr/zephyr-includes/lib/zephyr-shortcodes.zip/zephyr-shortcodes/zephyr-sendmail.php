<?php
// send the e-mail

?>