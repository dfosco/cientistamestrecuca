<?php
// default variables
if ( get_option('zephyr_accent_color') !== '' ) {
	$zephyr_accent_color = get_option('zephyr_accent_color');
} else {
	$zephyr_accent_color = '#FFFFFF';
}
?>
<div id="zephyrgenerator-form">
	<div id="zephyr-generator-tabs" class="wp-core-ui">
		<ul id="zephyr-generator-controls">
			<li><a href="#gen-1"><?php _e('Columns', 'zephyr'); ?></a></li>
			<li><a href="#gen-2"><?php _e('Buttons', 'zephyr'); ?></a></li>
			<li><a href="#gen-3"><?php _e('Quote', 'zephyr'); ?></a></li>
			<li><a href="#gen-4"><?php _e('Header Block', 'zephyr'); ?></a></li>
			<li><a href="#gen-5"><?php _e('Divider Lines', 'zephyr'); ?></a></li>
			<li><a href="#gen-6"><?php _e('Counters', 'zephyr'); ?></a></li>
			<li><a href="#gen-7"><?php _e('Update Boxes', 'zephyr'); ?></a></li>
			<li><a href="#gen-8"><?php _e('Author Boxes', 'zephyr'); ?></a></li>
			<li><a href="#gen-9"><?php _e('Dropcaps', 'zephyr'); ?></a></li>
			<li><a href="#gen-10"><?php _e('Chapters', 'zephyr'); ?></a></li>
			<li><a href="#gen-11"><?php _e('Company Info', 'zephyr'); ?></a></li>
			<li><a href="#gen-12"><?php _e('Contact Form', 'zephyr'); ?></a></li>
			<li><a href="#gen-13"><?php _e('Google maps', 'zephyr'); ?></a></li>
			<li><a href="#gen-14"><?php _e('Spacer', 'zephyr'); ?></a></li>
		</ul>
		<div id="gen-1">
			<h2><?php _e('Columns', 'zephyr'); ?></h2>
			<p><?php _e('Select the number of columns you want on a row.', 'zephyr'); ?></p>
			<p><input type="radio" name="zephyr-columns" id="zephyr-2cols" value="2" /> <label for="zephyr-2cols"><?php _e('Two columns', 'zephyr'); ?></label></p>
			<p><input type="radio" name="zephyr-columns" id="zephyr-3cols" value="3" /> <label for="zephyr-3cols"><?php _e('Three columns', 'zephyr'); ?></label></p>
			<p><input type="radio" name="zephyr-columns" id="zephyr-4cols" value="4" /> <label for="zephyr-4cols"><?php _e('Four columns', 'zephyr'); ?></label></p>
			<p><input type="radio" name="zephyr-columns" id="zephyr-6cols" value="6" /> <label for="zephyr-6cols"><?php _e('Six columns', 'zephyr'); ?></label></p>
			<p><input type="radio" name="zephyr-columns" id="zephyr-12cols" value="12" /> <label for="zephyr-12cols"><?php _e('Twelve columns', 'zephyr'); ?></label></p>
		</div>
		<div id="gen-2">
			<h2><?php _e('Buttons', 'zephyr'); ?></h2>
			<p>
				<label for="zephyr-button-text"><?php _e('Button text', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-button-text" id="zephyr-button-text" value="" />
			</p>
			<p>
				<label for="zephyr-button-url"><?php _e('Button url', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-button-url" id="zephyr-button-url" value="" />
			</p>
			<p><?php _e('Choose button style', 'zephyr'); ?></p>
			<p><input type="radio" name="zephyr-button-style" id="zephyr-button-regular" value="regular" /> <label for="zephyr-button-regular"><?php _e('Regular button', 'zephyr'); ?></label></p>
			<p><input type="radio" name="zephyr-button-style" id="zephyr-button-rounded" value="rounded" /> <label for="zephyr-button-rounded"><?php _e('Rounded button', 'zephyr'); ?></label></p>
			<p><?php _e('Choose button background color', 'zephyr'); ?></p>
			<p><input name="zephyr-button-color" type="text" id="zephyr-button-color" value="<?php echo $zephyr_accent_color; ?>" data-default-color="<?php echo $zephyr_accent_color; ?>"></p>
			<p><?php _e('Choose button border color', 'zephyr'); ?></p>
			<p><input name="zephyr-button-border-color" type="text" id="zephyr-button-border-color" value="<?php echo $zephyr_accent_color; ?>" data-default-color="<?php echo $zephyr_accent_color; ?>"></p>
			<p><?php _e('Choose button text color', 'zephyr'); ?></p>
			<p><input name="zephyr-button-text-color" type="text" id="zephyr-button-text-color" value="#3E3E3E" data-default-color="#3E3E3E"></p>
		</div>
		<div id="gen-3">
			<h2><?php _e('Quote', 'zephyr'); ?></h2>
			<p>
				<label for="zephyr-quote-text"><?php _e('Quote text', 'zephyr'); ?></label><br />
				<textarea name="zephyr-quote-text" id="zephyr-quote-text"></textarea>
			</p>
			<p>
				<label for="zephyr-quote-author"><?php _e('Quote author', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-quote-author" id="zephyr-quote-author" value="" />
			</p>
		</div>
		<div id="gen-4">
			<h2><?php _e('Header block', 'zephyr'); ?></h2>
			<p>
				<label for="zephyr-hb-bg"><?php _e('Background image url', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-hb-bg" id="zephyr-hb-bg" value="" />
				<div class="wp-media-buttons"><a title="<?php _e('Choose image', 'zephyr'); ?>" data-uploader_title="<?php _e('Header block Background', 'zephyr'); ?>" data-uploader_button_text="Insert image" class="upload_image_button button add_media" data-image_target="#zephyr-hb-bg" id="" href="#"><span class="wp-media-buttons-icon"></span> <?php _e('Choose Image', 'zephyr'); ?></a></div>
				<div class="clearfix"></div>
			</p>
			<p>
				<label for="zephyr-hb-title"><?php _e('Header block title', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-hb-title" id="zephyr-hb-title" />
			</p>
			<p>
				<label for="zephyr-hb-subtitle"><?php _e('Header block subtitle', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-hb-subtitle" id="zephyr-hb-subtitle" />
			</p>
			<p>
				<label for="zephyr-hb-title-color"><?php _e('Header block title color', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-hb-title-color" id="zephyr-hb-title-color" value="#5D5D5D" data-default-color="#5D5D5D" />
			</p>
			<p>
				<label for="zephyr-hb-subtitle-color"><?php _e('Header block subtitle color', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-hb-subtitle-color" id="zephyr-hb-subtitle-color" value="#5D5D5D" data-default-color="#5D5D5D" />
			</p>
			<p>
				<label for="zephyr-hb-height"><?php _e('Header block custom height ( px )', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-hb-height" id="zephyr-hb-height" value="" />
			</p>
		</div>
		<div id="gen-5">
			<h2><?php _e('Divider lines', 'zephyr'); ?></h2>
			<p><?php _e('Select divider line style', 'zephyr'); ?></p>
			<p><input type="radio" name="zephyr-divider" id="zephyr-divider-regular" value="regular" /> <label for="zephyr-divider-regular"><?php _e('Regular', 'zephyr'); ?></label></p>
			<p><input type="radio" name="zephyr-divider" id="zephyr-divider-dotted" value="dotted" /> <label for="zephyr-divider-dotted"><?php _e('Dotted', 'zephyr'); ?></label></p>
			<p><input type="radio" name="zephyr-divider" id="zephyr-divider-extra" value="extradotted" /> <label for="zephyr-divider-extra"><?php _e('Extra dotted', 'zephyr'); ?></label></p>
		</div>
		<div id="gen-6">
			<h2><?php _e('Counters', 'zephyr'); ?></h2>
			<p>
				<label for="zephyr-counter-title"><?php _e('Counter title', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-counter-title" id="zephyr-counter-title" />
			</p>
			<p>
				<label for="zephyr-counter-percent"><?php _e('Percent', 'zephyr'); ?></label><br />
				<div id="zephyr-counter-percent-slider"></div>
				<br />
				<input size="2" type="text" name="zephyr-counter-percent" id="zephyr-counter-percent" value="0" /> %
			</p>			
		</div>
		<div id="gen-7">
			<h2><?php _e('Update boxes', 'zephyr'); ?></h2>
			<p>
				<label for="zephyr-update-title"><?php _e('Update box title', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-update-title" id="zephyr-update-title" />
			</p>
			<p><?php _e('After the shortcode is inserted you can edit the content using the default wordpress editor.', 'zephyr'); ?></p>
		</div>
		<div id="gen-8">
			<h2><?php _e('Author boxes', 'zephyr'); ?></h2>
			<p><?php _e('Select Author box style', 'zephyr'); ?></p>
			<p><input type="radio" name="zephyr-author-style" id="zephyr-author-style-regular" value="regular" checked /> <label for="zephyr-author-style-regular"><?php _e('With background image', 'zephyr'); ?></label></p>
			<p><input type="radio" name="zephyr-author-style" id="zephyr-author-style-large" value="large" /> <label for="zephyr-author-style-large"><?php _e('Without background image', 'zephyr'); ?></label></p>
			<p>
				<label for="zephyr-author-name"><?php _e('Author name', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-author-name" id="zephyr-author-name" />
			</p>
			<p>
				<label for="zephyr-author-function"><?php _e('Author function', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-author-function" id="zephyr-author-function" />
			</p>
			<p>
				<label for="zephyr-author-image"><?php _e('Author image url', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-author-image" id="zephyr-author-image" value="" />
				<div class="wp-media-buttons"><a title="Choose image" data-uploader_title="Author image" data-uploader_button_text="Insert image" class="upload_image_button button add_media" data-image_target="#zephyr-author-image" id="" href="#"><span class="wp-media-buttons-icon"></span> <?php _e('Choose Image', 'zephyr'); ?></a></div>
				<div class="clearfix"></div>
			</p>
			<p>
				<label for="zephyr-author-bgimage"><?php _e('Background image url', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-author-bgimage" id="zephyr-author-bgimage" value="" />
				<div class="wp-media-buttons"><a title="Choose image" data-uploader_title="Author box - Background image" data-uploader_button_text="Insert image" class="upload_image_button button add_media" data-image_target="#zephyr-author-bgimage" id="" href="#"><span class="wp-media-buttons-icon"></span> <?php _e('Choose Image', 'zephyr'); ?></a></div>
				<br />
			</p>
			<p><?php _e('After the shortcode is inserted you can edit the author description using the default wordpress editor.', 'zephyr'); ?></p>
		</div>
		<div id="gen-9">
			<h2><?php _e('Dropcaps', 'zephyr'); ?></h2>
			<p><?php _e('Select dropcaps style', 'zephyr'); ?></p>
			<p><input type="radio" name="zephyr-dropcaps-style" id="zephyr-dropcaps-regular" value="regular" checked /> <label for="zephyr-dropcaps-regular"><?php _e('Regular', 'zephyr'); ?></label></p>
			<p><input type="radio" name="zephyr-dropcaps-style" id="zephyr-dropcaps-withbg" value="withbg" /> <label for="zephyr-dropcaps-withbg"><?php _e('With background color', 'zephyr'); ?></label></p>
			<p><?php _e('Choose dropcaps first letter color', 'zephyr'); ?></p>
			<p><input name="zephyr-dropcaps-first-color" type="text" id="zephyr-dropcaps-first-color" value="#333333" data-default-color="#333333"></p>
			<p><?php _e('Choose dropcaps background color', 'zephyr'); ?></p>
			<p><input name="zephyr-dropcaps-bg-color" type="text" id="zephyr-dropcaps-bg-color" value="<?php echo $zephyr_accent_color; ?>" data-default-color="<?php echo $zephyr_accent_color; ?>"></p>
		</div>
		<div id="gen-10">
			<h2><?php _e('Chapters', 'zephyr'); ?></h2>
			<p>
				<label for="zephyr-chapter-image"><?php _e('Background image ( optional )', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-chapter-image" id="zephyr-chapter-image" value="" />
				<div class="wp-media-buttons"><a title="Choose image" data-uploader_title="Chapter background image" data-uploader_button_text="Insert image" class="upload_image_button button add_media" data-image_target="#zephyr-chapter-image" id="" href="#"><span class="wp-media-buttons-icon"></span> <?php _e('Choose Image', 'zehpyr'); ?></a></div>
				<div class="clearfix"></div>
			</p>
			<p>
				<label for="zephyr-chapter-number"><?php _e('Chapter number', 'zephyr'); ?></label><br />
				<input size="2" type="text" name="zephyr-chapter-number" id="zephyr-chapter-number" />
			</p>
			<p><?php _e('Chapter number background color', 'zephyr'); ?></p>
			<p><input name="zephyr-chapter-color" type="text" id="zephyr-chapter-color" value="<?php echo $zephyr_accent_color; ?>" data-default-color="<?php echo $zephyr_accent_color; ?>"></p>
			<p>
				<label for="zephyr-chapter-title"><?php _e('Chapter title', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-chapter-title" id="zephyr-chapter-title" />
			</p>
		</div>
		<div id="gen-11">
			<h2><?php _e('Company info', 'zephyr'); ?></h2>
			<p><?php _e('Select Company info style', 'zephyr'); ?></p>
			<p><input type="radio" name="zephyr-cinfo-style" id="zephyr-cinfo-regular" value="regular" checked /> <label for="zephyr-cinfo-regular"><?php _e('Regular', 'zephyr'); ?></label></p>
			<p><input type="radio" name="zephyr-cinfo-style" id="zephyr-dropcaps-bgimg" value="bgimg" /> <label for="zephyr-dropcaps-bgimg"><?php _e('With background image', 'zephyr'); ?></label></p>
			<p><input type="radio" name="zephyr-cinfo-style" id="zephyr-dropcaps-bgimg-large" value="bgimg-large" /> <label for="zephyr-dropcaps-bgimg-large"><?php _e('With background image - large', 'zephyr'); ?></label></p>
			<p>
				<label for="zephyr-cinfo-bgimg"><?php _e('Background image', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-cinfo-bgimg" id="zephyr-cinfo-bgimg" value="" />
				<div class="wp-media-buttons"><a title="Choose image" data-uploader_title="Company info background image" data-uploader_button_text="Insert image" class="upload_image_button button add_media" data-image_target="#zephyr-cinfo-bgimg" id="" href="#"><span class="wp-media-buttons-icon"></span> <?php _e('Choose Image', 'zehpyr'); ?></a></div>
				<div class="clearfix"></div>
			</p>
			<p>
				<label for="zephyr-cinfo-logo"><?php _e('Logo', 'zehpyr'); ?></label><br />
				<input type="text" name="zephyr-cinfo-logo" id="zephyr-cinfo-logo" value="" />
				<div class="wp-media-buttons"><a title="Choose image" data-uploader_title="Company info logo" data-uploader_button_text="Insert image" class="upload_image_button button add_media" data-image_target="#zephyr-cinfo-logo" id="" href="#"><span class="wp-media-buttons-icon"></span> <?php _e('Choose Image', 'zehpyr'); ?></a></div>
				<div class="clearfix"></div>
			</p>
			<p>
				<label for="zephyr-cinfo-title"><?php _e('Title', 'zehpyr'); ?></label><br />
				<input type="text" name="zephyr-cinfo-title" id="zephyr-cinfo-title" />
			</p>
			<p>
				<label for="zephyr-cinfo-url"><?php _e('Link ( url )', 'zehpyr'); ?></label><br />
				<input type="text" name="zephyr-cinfo-url" id="zephyr-cinfo-url" />
			</p>
			<p>
				<label for="zephyr-cinfo-founded"><?php _e('Founded ( year )', 'zehpyr'); ?></label><br />
				<input type="text" name="zephyr-cinfo-founded" id="zephyr-cinfo-founded" />
			</p>
			<p>
				<label for="zephyr-cinfo-location"><?php _e('Location', 'zehpyr'); ?></label><br />
				<input type="text" name="zephyr-cinfo-location" id="zephyr-cinfo-location" />
			</p>
		</div>
		<div id="gen-12">
			<h2><?php _e('Contact form', 'zephyr'); ?></h2>
			<p><?php _e('Choose a contact form:', 'zephyr'); ?></p>
			<div id="zephyr-cfs">
			<?php wpseRCF_grid_action_ajax(); ?>
			</div>
			<p><?php _e('Or create a new form by filling in your email:', 'zephyr'); ?></p>
			<p>
				<label for="zephyr-contact-email"><?php _e('Email', 'zehpyr'); ?></label><br />
				<input type="text" name="zephyr-contact-email" id="zephyr-contact-email" />
			</p>
			<p>
				<div class="wp-media-buttons"><a title="<?php _e('Create Contact form', 'zephyr'); ?>" class="button add_media" id="zephyr-addcf" href="#"><?php _e('Create Contact form', 'zephyr'); ?></a></div>
				<div class="clearfix"></div>
			</p>
			<p>
			<small><?php _e('If no form is selected the administrator e-mail address will be used', 'zephyr'); ?></small>
			</p>
		</div>
		<div id="gen-13">
			<h2><?php _e('Google maps', 'zephyr'); ?></h2>
			<p>
				<label for="zephyr-gmaps-latitude"><?php _e('Latitude', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-gmaps-latitude" id="zephyr-gmaps-latitude" />
			</p>
			<p>
				<label for="zephyr-gmaps-longitude"><?php _e('Longitude', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-gmaps-longitude" id="zephyr-gmaps-longitude" /><br />
				<small><?php _e('You can easily obtain those', 'zephyr'); ?> <a href="http://itouchmap.com/latlong.html" target="_blank"><?php _e('here', 'zephyr'); ?></a></small>
			</p>
			<p>
				<label for="zephyr-gmaps-zoom"><?php _e('Zoom level', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-gmaps-zoom" id="zephyr-gmaps-zoom" />
			</p>
			<p>
				<label for="zephyr-gmaps-marker"><?php _e('Marker message', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-gmaps-marker" id="zephyr-gmaps-marker" />
			</p>
			<p>
				<label for="zephyr-gmaps-height"><?php _e('Height ( px )', 'zephyr'); ?></label><br />
				<input type="text" name="zephyr-gmaps-height" id="zephyr-gmaps-height" />			
			</p>
		</div>
		<div id="gen-14">
			<h2><?php _e('Spacer', 'zephyr'); ?></h2>
			<p><?php _e('No options here, just insert the shortcode to get some spacing.', 'zephyr'); ?></p>
		</div>
		<div class="clearfix"></div>
		<p class="submit">
			<input type="button" id="zephyrgenerator-submit" class="button-primary" value="<?php _e('Insert Shortcodes', 'zehpyr'); ?>" name="submit" />
		</p>
	</div>
</div>