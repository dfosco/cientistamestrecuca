<?php
if ( ! defined( 'ABSPATH' ) )
    die( "Can't load this file directly" );
 
class Zephyr_Shortcode_Generator {
	function __construct() {
		add_action( 'admin_init', array( $this, 'action_admin_init' ) );
	}
 
	function action_admin_init() {
		// only hook up these filters if we're in the admin panel, and the current user has permission
		// to edit posts and pages
		if ( current_user_can( 'edit_posts' ) && current_user_can( 'edit_pages' ) ) {
			add_filter( 'mce_buttons', array( $this, 'filter_mce_button' ) );
			add_filter( 'mce_external_plugins', array( $this, 'filter_mce_plugin' ) );
			wp_enqueue_script( 'jquery-ui-core' );
			wp_enqueue_script( 'jquery-ui-tabs' );
			wp_enqueue_script( 'jquery-ui-slider' );
			wp_enqueue_script( 'jquery-ui-dialog' );
			wp_register_style( 'jquery-ui-css', plugins_url( 'css/zephyr/jquery-ui-1.10.3.custom.min.css' , __FILE__ ), array(), '1.10.3');
			wp_enqueue_style( 'jquery-ui-css' );
			wp_enqueue_script('wp-color-picker');
			wp_enqueue_style( 'wp-color-picker' );
		}
	}
 
	function filter_mce_button( $buttons ) {
		// add a separation before our button, here our button's id is &quot;mygallery_button&quot;
		array_push( $buttons, '|', 'zephyrgenerator_button' );
		return $buttons;
	}
 
	function filter_mce_plugin( $plugins ) {
		// this plugin file will work the magic of our button
		$plugins['zephyrgenerator'] = plugin_dir_url( __FILE__ ) . 'shortcode-generator.js';
		return $plugins;
	}
}

	add_action('wp_ajax_wpse73257_grid_action_ajax', 'wpse73257_grid_action_ajax');
	function wpse73257_grid_action_ajax(){
		include_once('shortcode-form.php');
		exit;
	}
	add_action('wp_ajax_wpseZCF_grid_action_ajax', 'wpseZCF_grid_action_ajax');
	function wpseZCF_grid_action_ajax() {
		$email = $_POST['cfemail'];
		$contact_forms = get_option('zephyr-contact-forms');
		if ( empty($contact_forms) ) {
			$cf = Array('1' => $email);
			$newval = json_encode($cf);
			update_option( 'zephyr-contact-forms' , $newval);
			echo true;
		} else {
			$cfs = json_decode($contact_forms, true);
			$last = max(array_keys($cfs));
			$new = ($last+1);
			$cfs[$new] = $email;
			$newval = json_encode($cfs);
			update_option( 'zephyr-contact-forms' , $newval);
			echo true;
		}
		exit;
	}
	add_action('wp_ajax_wpseRCF_grid_action_ajax', 'wpseRCF_grid_action_ajax');
	function wpseRCF_grid_action_ajax() {
		 $contact_forms = get_option('zephyr-contact-forms');
			if ( !empty($contact_forms) ) {
				$contacts = json_decode($contact_forms);
				foreach ( $contacts as $id => $email ) {
					echo '<div class="wp-media-buttons"><a title="'.$email.'" class="button cfss" data-cfid="'.$id.'" href="#">'.$email.'</a></div>';
				}
				echo '<div class="clearfix"></div>';
			} else {
				echo '<em>'.__('No contact forms created', 'zephyr').'</em>';
			}
			if ( $_POST['action'] == 'wpseRCF_grid_action_ajax' ) {
			exit;
			}
	}
$shortcode_generator = new Zephyr_Shortcode_Generator();
?>