<?php   
	/* 
	Plugin Name: Zephyr Shortcodes
	Plugin URI: http://www.themeflame.org 
	Description: This plugin provides the shortcodes used by the Zephyr Template
	Author: Themeflame
	Version: 1.1 
	Author URI: http://www.themeflame.org 
	*/



function zephyr_shortcode_scripts() {
	wp_register_style( 'zephyr_shortcodes_css', plugins_url( 'css/zephyr-shortcodes.css' , __FILE__ ), array(), '1.0');
	wp_register_style( 'zephyr_contact_css', plugins_url( 'zephyr_contact.css' , __FILE__ ), array(), '1.1');
	wp_enqueue_style( 'zephyr_contact_css' );
	if ( wp_get_theme() !== 'Zephyr' ) {
		wp_enqueue_style( 'zephyr_shortcodes_css' );		
	}
	
	wp_register_script( 'zephyr_contact_js', plugins_url( 'js/zephyr_contact.js' , __FILE__ ), array('jquery'), '1.0', true );
	wp_register_script('googlemaps', ('http://maps.google.com/maps/api/js?sensor=false'), false, null, true);
	wp_enqueue_script( 'zephyr_contact_js' );
	wp_enqueue_script('googlemaps');
	wp_localize_script( 'zephyr_contact_js', 'ZephyrAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
}

add_action( 'wp_enqueue_scripts', 'zephyr_shortcode_scripts' );
add_action( 'wp_ajax_nopriv_myajax-submit', 'myajax_submit' );
add_action( 'wp_ajax_myajax-submit', 'zephyr_sendmail' );

// add shortcode generator button to tinymce editor
require_once( 'zephyr-shortcode-generator.php' );

function zephyr_remove_p( $string )
{
    $patterns = array(
        '#^\s*</p>#',
        '#<p>\s*$#'
    );

    return preg_replace($patterns, '', $string);
}

function zephyr_sendmail() {
	$id = $_POST['id'];
	if ( !empty($id) ) {
		$contact_forms = get_option('zephyr-contact-forms');
		if ( !empty($contact_forms) ) {
			$contacts = json_decode($contact_forms, true);
			$to = $contacts[$id];
		}
	} else {
		$to = get_option('admin_email');
	}
	$name = $_POST['name'];
	$email = $_POST['email'];
	$message = $_POST['message'];
	$subject = 'New contact message!';
	$headers = "From: {$name} <{$email}>" . "\r\n";
	wp_mail( $to, $subject, $message, $headers );
	$response = json_encode( array( 'success' => 'true' ) );
	header( "Content-Type: application/json" );
	echo $response;
	exit;
}

function zephyr_contact_form( $atts, $content = null ) {
	$a = shortcode_atts( array(
		'centered' => '0',
		'id' => ''
	), $atts);
	if ( $a['centered'] ) { $class = 'c-label'; } else { $class = ''; }
	$markup =	'
			<div class="comment-form col-md-12 '.$class.'">
				<input type="hidden" id="zcf-id" value="'.$a['id'].'" />
				<div class="form-row">
					<label for="yourname">'.__('YOUR NAME', 'zephyr').':</label><span><input id="yourname" name="yourname" type="text" /></span>
				</div>
				<div class="form-row">
					<label for="youremail">'.__('YOUR EMAIL', 'zephyr').':</label><span><input id="youremail" name="youremail" type="email" /></span>
				</div>
				<div class="form-row">
					<label for="yourmess">'.__('YOUR MESSAGE', 'zephyr').':</label>
					<textarea id="yourmess" name="yourmess"></textarea>
				</div>
				<div class="form-row noborder">
					<button id="sendform" class="submit accentbg">'.__('SEND', 'zephyr').'</button>
					<div class="loading"></div>
				</div>
			</div>';
	return $markup;
}
add_shortcode("zephyr_contact_form", "zephyr_contact_form");

function zephyr_columns( $atts, $content = null ) {
	return '<div class="row">'.do_shortcode($content).'<div class="clearfix"></div></div>';
}
add_shortcode("zephyr_columns", "zephyr_columns");

function zephyr_column( $atts, $content = null ) {
	$a = shortcode_atts( array(
		'col' => '1'
	), $atts);
	$colnum = $a['col'];
	$col = 12 / $colnum;
	return '<div class="col-md-'.$col.' col-sm-'.$col.' col-xs-12">'.do_shortcode(apply_filters('the_content', zephyr_remove_p($content))).'<div class="clearfix"></div></div>';
}
add_shortcode("zephyr_column", "zephyr_column");

function zephyr_quote( $atts, $content = null ) {
	return '<div class="post-quote">
		<div class="quote">
			<p>'.$content.'</p>
		</div>
		<div class="quote-author">
			<span class="quote-icon"></span> '.__('quote by', 'zephyr').' '.$atts['author'].'
		</div>
	</div>';
}
add_shortcode("zephyr_quote", "zephyr_quote");

function zephyr_company_info( $atts, $content = null ) {
	$a = shortcode_atts( array(
		'style' => '',
		'bgimg' => '',
		'logo' => '',
		'title' => 'ThemeFlame',
		'url' => 'http://themeflame.org',
		'founded' => '2012',
		'location' => 'Paris, France'
	), $atts );
	$style = $a['style'];
	$bgimg = $a['bgimg'];
	$logo = $a['logo'];
	$title = $a['title'];
	$url = $a['url'];
	$founded = $a['founded'];
	$location = $a['location'];
	if ( $style == 'bgimg' ) {
		return	'<div class="about-box-img-small">
					<div class="row">
						<div class="col-md-12">
							<div class="imgwlogo">
								<img src="'.$bgimg.'" class="bg-img" alt="'.$title.'" />
								<div class="contwlogo row">
									<div class="col-md-7">
										<div class="logo-img col-md-3 col-xs-3">
											<img src="'.$logo.'" alt="'.$title.'" />
										</div>
										<div class="logo-name col-md-9 col-xs-9">
											<h3>'.$title.'</h3>
											<em><a href="'.$url.'" target="_blank">'.$url.'</a></em>
										</div>
									</div>
									<div class="col-md-4 col-md-offset-1">
										<h4>'.__('FOUNDED', 'zephyr').': <span class="info">'.$founded.'</span></h4>
										<h4>'.__('LOCATION', 'zephyr').': <span class="info">'.$location.'</span></h4>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							'.apply_filters('the_content', $content).'
						</div>
					</div>
				</div>';
	} elseif ( $style == 'bgimg-large' ) {
		return '<div class="about-box-img-large">
			<div class="row">
				<div class="col-md-12 col-xs-12">
					<div class="imgwlogo">
						<img src="'.$bgimg.'" class="bg-img" alt="'.$title.'" />
						<div class="contwlogo">
							<img src="'.$logo.'" alt="'.$title.'" />
							<h3>'.$title.'</h3>
							<em><a href="'.$url.'" target="_blank">'.$url.'</a></em>
						</div>
					</div>
				</div>
			</div>
			<div class="row details">
					<h4>'.__('FOUNDED', 'zephyr').': <span class="info">'.$founded.'</span></h4>
					<h4>'.__('LOCATION', 'zephyr').': <span class="info">'.$location.'</span></h4>
			</div>
			<div class="row">
				<div class="col-md-12">
					'.apply_filters('the_content', $content).'
				</div>
			</div>
		</div>';
	} else {
		return	'<div class="about-box">
				<div class="row details">
					<div class="col-md-7">
						<div class="logo-img col-md-3 col-xs-3">
							<img src="'.$logo.'" alt="'.$title.'" />
						</div>
						<div class="logo-name col-md-9 col-xs-9">
							<h3>'.$title.'</h3>
							<em><a href="'.$url.'" target="_blank">'.$url.'</a></em>
						</div>
					</div>
					<div class="col-md-4 col-md-offset-1">
						<h4>'.__('FOUNDED', 'zephyr').': <span class="info">'.$founded.'</span></h4>
						<h4>'.__('LOCATION', 'zephyr').': <span class="info">'.$location.'</span></h4>
					</div>
				</div>
				<div class="row punchline">
					<div class="col-md-12">
						'.apply_filters('the_content', $content).'
					</div>
				</div>
			</div>';
	}
}
add_shortcode("zephyr_company_info", "zephyr_company_info");

function zephyr_header_block( $atts, $content = null ) {
	$a = shortcode_atts( array(
		'bgimg' => '',
		'title' => 'Brilliancy',
		'subtitle' => 'COMES WITH GREAT EFFORT & PASSION',
		'titlecolor' => '',
		'subtitlecolor' => '',
		'height' => ''
	), $atts );
	$bgimg = $a['bgimg'];
	$title = $a['title'];
	$subtitle = $a['subtitle'];
	if ( $a['titlecolor'] !== '' ) { $titlecolor = 'style="color: '.$a['titlecolor'].'"'; } else { $titlecolor = ''; }
	if ( $a['subtitlecolor'] !== '' ) { $subtitlecolor = 'style="color: '.$a['subtitlecolor'].'"'; } else { $subtitlecolor = ''; }
	if ( $a['height'] !== '' ) { $height = 'style="height: '.$a['height'].'px;"'; } else { $height = ''; }
	return  '<div class="header-block" '.$height.'>
				<img src="'.$bgimg.'" alt="'.$title.'" class="bg-img" />
				<div class="header-block-content">
					<h1 '.$titlecolor.'>'.$title.'</h1>
					<h2 '.$subtitlecolor.'>'.$subtitle.'</h2>
					<p>'.do_shortcode($content).'</p>
				</div>
			</div>';
}
add_shortcode("zephyr_header_block", "zephyr_header_block");

function zephyr_spacer($atts) {
	return '<div class="row spacer"></div>';
}
add_shortcode("zephyr_spacer", "zephyr_spacer");

function zephyr_divider($atts) {
	$a = shortcode_atts( array(
		'style' => 'solid'
	), $atts );
	
	return '<div class="divider '.$a['style'].'"></div>';
}
add_shortcode("zephyr_divider", "zephyr_divider");

function zephyr_counter($atts) {
	$a = shortcode_atts( array(
		'percent' => '29',
		'title' => 'Counter title'
	), $atts );

	return  '<div class="counter-in">
				<h2><span class="count" data-count="'.$a['percent'].'">0</span>%</h2>
				<h3>'.$a['title'].'</h3>
				<div class="separator"></div>
			</div>';
}
add_shortcode("zephyr_counter", "zephyr_counter");

function zephyr_update_box($atts, $content = null) {
	$a = shortcode_atts( array(
		'title' => 'UPDATE #1  -  24.05  -  16:05 PM'
	), $atts );
	return	'<div class="update-box">
				<div class="update-box-title">
					<h2>'.$a['title'].'</h2>
				</div>
				<div class="update-box-content">
					'.apply_filters('the_content', $content).'
				</div>
			</div>';
}
add_shortcode("zephyr_update_box", "zephyr_update_box");

function zephyr_button($atts, $content = null) {
	if ( get_option('zephyr_accent_color') ) { $default_bg = get_option('zephyr_accent_color'); } else { $default_bg = '#ffd773'; }
	$a = shortcode_atts( array(
		'style' => '',
		'bgcolor' => $default_bg,
		'border' => '',
		'textcolor' => '',
		'url' => '#'
	), $atts );
	if ( $a['border'] == '' ) {
		$a['border'] = $a['bgcolor'];
	}
	return '<a href="'.$a['url'].'" class="accentbg accentborder zephyr-button '.$a['style'].'" style="background-color:'.$a['bgcolor'].'; border-color: '.$a['border'].'; color: '.$a['textcolor'].'">'.$content.'</a>';
}
add_shortcode("zephyr_button", "zephyr_button");

function zephyr_author_box($atts, $content = null) {
	$a = shortcode_atts( array(
		'style' => '',
		'bgimg' => '',
		'authorimg' => '',
		'name' => 'John Doe',
		'function' => 'THEMEFLAME INC., CEO'
	), $atts );
	if ( $a['style'] == 'large' ) {
		return	'<div class="author-box-large">
					<div class="author-box-large-info col-md-3">
						<img src="'.$a['authorimg'].'" alt="'.$a['name'].'" class="round" />
						<h2>'.$a['name'].'</h2>
						<h3>'.$a['function'].'</h3>
					</div>
					<div class="author-box-large-desc col-md-8 col-md-offset-1">
						'.apply_filters('the_content', $content).'
					</div>
				</div>';
	} else {
		return	'<div class="author-box">
					<div class="author-box-top">
						<img src="'.$a['bgimg'].'" alt="'.$a['name'].'" />
						<div class="author-info">
							<div class="author-info-img round">
								<img src="'.$a['authorimg'].'" alt="'.$a['name'].'" />
							</div>
							<h2>'.$a['name'].'</h2>
							<h3>'.$a['function'].'</h3>
						</div>
					</div>
					<div class="author-desc">
						'.apply_filters('the_content', $content).'
					</div>
				</div>';
	}
}
add_shortcode("zephyr_author_box", "zephyr_author_box");

function zephyr_dropcaps($atts, $content = null) {
	$a = shortcode_atts( array(
		'style' => '',
		'bgcolor' => '',
		'firstcolor' => ''
	), $atts );
	$content = strip_tags($content);
	$firstletter = $content[0];
	$text = substr($content, 1);
	if ( $a['firstcolor'] !== '' ) { $firstcolor = 'color: '.$a['firstcolor'].';'; } else { $firstcolor = ''; }
	if ( $a['style'] == 'withbg' ) {
		if ( $a['bgcolor'] !== '' ) { $bgcolor = 'background-color: '.$a['bgcolor'].';'; } else { $bgcolor = ''; }
		$style = 'style="'.$firstcolor.$bgcolor.'"';
		return '<div class="zephyr-dropcaps '.$a['style'].'"><span class="first-letter left round withbg accentbg" '.$style.'>'.$firstletter.'</span>'.apply_filters('the_content', $text).'</div>';
	} else {
		$style = 'style="'.$firstcolor.'"';
		return '<div class="zephyr-dropcaps '.$a['style'].'"><span class="first-letter left" '.$style.'>'.$firstletter.'</span>'.apply_filters('the_content', $text).'</div>';
	}
}
add_shortcode("zephyr_dropcaps", "zephyr_dropcaps");

function zephyr_chapter($atts, $content = null) {
	$a = shortcode_atts( array(
		'number' => '01',
		'bgcolor' => '',
		'title' => 'Chapter 1',
		'bgimg' => ''
	), $atts );
	if ( $a['bgcolor'] !== '' ) { $bgcolor = 'style="background-color: '.$a['bgcolor'].'"'; } else { $bgcolor = ''; }
	if ( $a['bgimg'] !== '' ) { $bgimg = '<img src="'.$a['bgimg'].'" alt="'.$a['title'].'" /><br />'; } else { $bgimg = ''; }
	return '<div class="zephyr-chapter">
				<div class="zephyr-chapter-top">
					'.$bgimg.'
					<div class="chapter-number accentbg round" '.$bgcolor.'>
						'.$a['number'].'
					</div>
					<h3>'.$a['title'].'</h3>
					<div class="separator"></div>
				</div>
				<div class="zephyr-chapter-text">
					'.apply_filters('the_content', $content).'
				</div>
			</div>';
}
add_shortcode("zephyr_chapter", "zephyr_chapter");

function zephyr_image_text($atts) {
	$a = shortcode_atts( array(
		'title' => 'Contact Us',
		'subtitle' => 'NEW YORK CITY, ROSH ST. 252A, 26. US',
		'subtext' => 'PHONE NUMBER: 555.253.217',
		'bgimg' => ''
	), $atts );
	return	'<div class="image-text">
				<img src="'.$a['bgimg'].'" alt="'.$a['title'].'" />
				<div class="image-text-text">
					<h1>'.$a['title'].'</h1>
					<div class="sep white"></div>
					<p>'.$a['subtitle'].'</p>
					<p><small>'.$a['subtext'].'</small></p>
				</div>
			</div>';
}
add_shortcode("zephyr_image_text", "zephyr_image_text");

function zephyr_gmap($atts) {
    $a = shortcode_atts(array(
    		"id" => uniqid(),
    		"type" => 'road',
    		"latitude" => '53.801279',
    		"longitude" => '-1.548567',
    		"zoom" => '15',
    		"message" => 'Themeflame!',
    		"width" => '100%',
    		"height" => '360'
    	), $atts);
    $mapType = '';
    if($a['type'] == "satellite")
        $mapType = "SATELLITE";
    else if($a['type'] == "terrain")
        $mapType = "TERRAIN"; 
    else if($a['type'] == "hybrid")
        $mapType = "HYBRID";
    else
        $mapType = "ROADMAP"; 
         
    echo '<!-- Google Map -->
        <script type="text/javascript"> 
        jQuery(document).ready(function($) {
          function initializeGoogleMap() {
     
              var myLatlng = new google.maps.LatLng('.$a['latitude'].','.$a['longitude'].');
              var myOptions = {
                center: myLatlng, 
                zoom: '.$a['zoom'].',
                mapTypeId: google.maps.MapTypeId.'.$mapType.'
              };
              var map = new google.maps.Map(document.getElementById("'.$a['id'].'"), myOptions);
     
              var contentString = "'.$a['message'].'";
              var infowindow = new google.maps.InfoWindow({
                  content: contentString
              });
               
              var marker = new google.maps.Marker({
                  position: myLatlng
              });
               
              google.maps.event.addListener(marker, "click", function() {
                  infowindow.open(map,marker);
              });
              marker.setMap(map);
          }
          initializeGoogleMap();
        });
        </script>';
     
        return '<div id="'.$a['id'].'" style="width:'.$a['width'].'px; height:'.$a['height'].'px;" class="googleMap"></div>';
}
add_shortcode("zephyr_gmap", "zephyr_gmap");

function zephyr_heading($atts, $content = null) {
    $a = shortcode_atts(array(
    		"size" => "30",
    		"tag" => "h1",
    		"align" => "center",
    		"type" => ""
	), $atts);
	return '<'.$a['tag'].' class="'.$a['type'].'" style="font-size: '.$a['size'].'; text-align: '.$a['align'].'">'.$content.'</'.$a['tag'].'>';
}
add_shortcode("zephyr_heading", "zephyr_heading");

add_filter( 'post_gallery', 'my_post_gallery', 10, 2 );
function my_post_gallery( $output, $attr) {
   global $post, $wp_locale;

    static $instance = 0;
    $instance++;

    // We're trusting author input, so let's at least make sure it looks like a valid orderby statement
    if ( isset( $attr['orderby'] ) ) {
        $attr['orderby'] = sanitize_sql_orderby( $attr['orderby'] );
        if ( !$attr['orderby'] )
            unset( $attr['orderby'] );
    }
    extract(shortcode_atts(array(
        'order'      => 'ASC',
        'orderby'    => 'menu_order ID',
        'id'         => $post->ID,
        'itemtag'    => 'dl',
        'icontag'    => 'dt',
        'captiontag' => 'dd',
        'columns'    => 3,
        'size'       => 'thumbnail',
        'include'    => '',
        'exclude'    => ''
    ), $attr));

    $id = intval($id);
    if ( 'RAND' == $order )
        $orderby = 'none';

    if ( !empty($include) ) {
        $include = preg_replace( '/[^0-9,]+/', '', $include );
        $_attachments = get_posts( array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );

        $attachments = array();
        foreach ( $_attachments as $key => $val ) {
            $attachments[$val->ID] = $_attachments[$key];
        }
    } elseif ( !empty($exclude) ) {
        $exclude = preg_replace( '/[^0-9,]+/', '', $exclude );
        $attachments = get_children( array('post_parent' => $id, 'exclude' => $exclude, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
    } else {
        $attachments = get_children( array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
    }

    if ( empty($attachments) )
        return '';

    if ( is_feed() ) {
        $output = "\n";
        foreach ( $attachments as $att_id => $attachment )
            $output .= wp_get_attachment_link($att_id, $size, true) . "\n";
        return $output;
    }

    $itemtag = tag_escape($itemtag);
    $captiontag = tag_escape($captiontag);
    $columns = intval($columns);
    $itemwidth = $columns > 0 ? floor(100/$columns) : 100;
    $float = is_rtl() ? 'right' : 'left';

    $selector = "gallery-{$instance}";

    $i = 0;
    $class = '';
    $isize = '';
	if ( $columns == 1 ) {
		$isize = 'zephyr-postlist';
		$class = 'col-md-12';
	}
	if ( $columns == 2 ) {
		$isize = 'zephyr-galllery-2col';
		$class = 'col-md-6';
	}
	if ( $columns == 3 ) {
		$isize = 'zephyr-galllery-3col';
		$class = 'col-md-4';
	}
	if ( $columns == 4 ) {
		$isize = 'zephyr-galllery-4col';
		$class = 'col-md-3';
	}
	if ( $columns >= 5 ) {
		$isize = 'zephyr-galllery-4col';
		$class = 'col-md-2';
	}
	$output .= '<div class="zephyr-gallery" id="'.$selector.'">';
    foreach ( $attachments as $id => $attachment ) {
		$image = wp_get_attachment_image_src($id, $isize);
		$large = wp_get_attachment_image_src($id, 'large');
		$alt = get_post_meta( $id, '_wp_attachment_image_alt', true );
		if ( $alt == '' ) { $alt = get_the_title(); }
		$output .=  '<div class="centered '.$class.'">';
		$output .= 	'<a class="fancybox" rel="'.$selector.'" href="'.$large[0].'"><img src="'.$image[0].'" alt="'.$alt.'"></a>';
		$output .=  '</div>';
    }

    $output .= "
        </div>\n";

    return $output;
}

?>